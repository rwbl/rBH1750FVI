Changelog rBH1750FVI

20170215 (v1.0.1)
NEW: Property change GetLightIntensity to getLightIntensity; added code examples.

20170131 (v1.0.0)
NEW: First version published.
