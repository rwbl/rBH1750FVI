//B4R Library wrapped based on project https://github.com/Genotronex/BH1750FVI_Master
// Changelog
// 20170215: v1.01 - property change GetLightIntensity to getLightIntensity; added code examples.
// 20170127: v1.0
#pragma once
#include "B4RDefines.h"
#include "BH1750FVI.h"
//~Author: Robert W.B. Linn
//~Version: 1.01
namespace B4R {
	//~shortname: BH1750FVI
	/**
	*Wrapper for <link>Digital Light Sensor BH1750|https://github.com/Genotronex/BH1750FVI_Master</link> library. 
	*/
	class B4RBH1750FVI {
		private:
			BH1750FVI* bh;
			uint8_t be[sizeof(BH1750FVI)];
		public:
			/**
			*Initialize the sensor with address and resolution mode.
			*Example (Private bh As BH1750FVI):<code>
			*'Init the sensor with low address 0x23 and the recommended high resolution mode
			*bh.Initialize(bh.Device_Address_L, bh.Continuous_H_resolution_Mode)
			*</code>
			*/
  		void Initialize(Int address, Byte mode);

			/**
			*Get the lightintensity in Lux.
			*Example (Private bh As BH1750FVI):<code>
			*Log(bh.LightIntensity, "lx")
			*</code>
			*/
  		UInt getLightIntensity();

    	/**
    	*Set sleep mode
    	*/
    	void SetSleep(); 
    
    	/**
    	*Set measurement mode
    	*/
    	void SetMode(Int mode);
    
    	/**
    	*Reset
    	*/
    	void SetReset();
    
    	/**
    	*Set the address 0x23 or 05x
    	*/
    	void SetAddress(Int addr);

			//Device address when address pin LOW 0x23
			#define /*Byte Device_Address_L;*/ B4RBH1750FVI_Device_Address_L 0x23 
		
			//Device address when address pin HIGH 0x5C
			#define /*Byte Device_Address_H;*/ B4RBH1750FVI_Device_Address_H 0x5C 

			#define /*Byte Power_Down;*/ B4RBH1750FVI_Power_Down 0x00
		
			#define /*Byte Power_On;*/ B4RBH1750FVI_Power_On 0x01
		
			#define /*Byte reset;*/ B4RBH1750FVI_reset 0x07
		
			//Start measurement at 1lx resolution. Measurement Time is typically 120ms. Recommended.
			#define /*Byte Continuous_H_resolution_Mode;*/ B4RBH1750FVI_Continuous_H_resolution_Mode  0x10

			//Start measurement at 0.5lx resolution. Measurement Time is typically 120ms. 
			#define /*Byte Continuous_H_resolution_Mode2;*/ B4RBH1750FVI_Continuous_H_resolution_Mode2  0x11

			//Start measurement at 4lx resolution. Measurement Time is typically 16ms.
			#define /*Byte Continuous_L_resolution_Mode;*/ B4RBH1750FVI_Continuous_L_resolution_Mode  0x13

			//Start measurement at 1lx resolution. Measurement Time is typically 120ms. It is automatically set to Power Down mode after measurement.
			#define /*Byte OneTime_H_resolution_Mode;*/ B4RBH1750FVI_OneTime_H_resolution_Mode  0x20

			//Start measurement at 0.5lx resolution. Measurement Time is typically 120ms. It is automatically set to Power Down mode after measurement.
			#define /*Byte OneTime_H_resolution_Mode2;*/ B4RBH1750FVI_OneTime_H_resolution_Mode2  0x21

			//Start measurement at 4lx resolution. Measurement Time is typically 16ms. It is automatically set to Power Down mode after measurement.
			#define /*Byte OneTime_L_resolution_Mode;*/ B4RBH1750FVI_OneTime_L_resolution_Mode  0x23

			//Address pin enable = default is pin A3
			#define /*UInt AddrPin;*/ AddrPin 17
		
	};
}