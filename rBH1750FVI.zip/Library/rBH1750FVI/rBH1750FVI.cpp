#include "B4RDefines.h"
namespace B4R {
		//Init the sensor with address and mode
		void B4RBH1750FVI::Initialize(Int address, Byte mode) {
			bh = new (be) BH1750FVI();
			bh->begin();
			bh->SetAddress(address);
			bh->SetMode(Continuous_H_resolution_Mode);
		}

    //Set sleep mode
    void B4RBH1750FVI::SetSleep() {
    	bh->Sleep();
    }; 
    
    //Set measurement mode
    void B4RBH1750FVI::SetMode(Int mode){
    	bh->SetMode(mode);
    };
    
    //Reset
    void B4RBH1750FVI::SetReset(){
    	bh->Reset();
    };
    
    //Set the address 0x23 or 05x
    void B4RBH1750FVI::SetAddress(Int addr){
    	bh->SetAddress(addr);
    };

		//Get the light intensity
		UInt B4RBH1750FVI::getLightIntensity() {
			return bh->GetLightIntensity();
		}

}
